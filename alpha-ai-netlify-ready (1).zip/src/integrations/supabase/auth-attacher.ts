import { createMiddleware } from '@tanstack/react-start'
import { getSupabase } from './client'

/** Attaches Supabase session when configured; otherwise continues as guest. */
export const attachSupabaseAuth = createMiddleware().server(async ({ next, request }) => {
  try {
    const client = getSupabase()
    if (!client) return next()
    const { data } = await client.auth.getSession()
    // Session available for downstream if needed; do not block the request.
    void data
  } catch (e) {
    console.warn('[alpha] supabase auth attach skipped:', e)
  }
  return next()
})
