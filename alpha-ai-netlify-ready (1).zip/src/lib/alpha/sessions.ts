import type { UIMessage } from "ai";
import { readJSON, writeJSON, removeKey } from "./storage";

export type SessionMeta = { id: string; title: string; updatedAt: number };

const INDEX_KEY = "alpha.sessions.v1";
const msgKey = (id: string) => `alpha.session.${id}`;
const listeners = new Set<() => void>();

export function onSessionsChange(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}
const notify = () => listeners.forEach((l) => l());

const isIndex = (v: unknown): v is SessionMeta[] =>
  Array.isArray(v) && v.every((s) => s && typeof s.id === "string" && typeof s.title === "string");

export const isValidId = (id: string) => /^[a-z0-9-]{6,40}$/i.test(id);

export function listSessions(): SessionMeta[] {
  return readJSON<SessionMeta[]>(INDEX_KEY, [], isIndex).sort((a, b) => b.updatedAt - a.updatedAt);
}

export function newSessionId() {
  try { return crypto.randomUUID(); } catch { return `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`; }
}

export function loadMessages(id: string): UIMessage[] {
  return readJSON<UIMessage[]>(msgKey(id), [], (v): v is UIMessage[] => Array.isArray(v));
}

function titleFrom(messages: UIMessage[]) {
  const first = messages.find((m) => m.role === "user");
  const text = first?.parts.map((p) => (p.type === "text" ? p.text : "")).join(" ").trim() ?? "";
  return text ? text.slice(0, 48) + (text.length > 48 ? "…" : "") : "New chat";
}

/** Saves messages. Only writes to the index once the chat has content, so empty chats don't pile up. */
export function saveMessages(id: string, messages: UIMessage[]) {
  if (!messages.length) return true;
  // Strip large inline image data from persisted history to protect storage quota.
  const slim = messages.map((m) => ({
    ...m,
    parts: m.parts.map((p) =>
      p.type === "file" && p.url.length > 200_000 ? { ...p, url: "" } : p,
    ),
  }));
  const ok = writeJSON(msgKey(id), slim);
  const index = listSessions().filter((s) => s.id !== id);
  index.unshift({ id, title: titleFrom(messages), updatedAt: Date.now() });
  writeJSON(INDEX_KEY, index.slice(0, 100));
  notify();
  return ok;
}

export function renameSession(id: string, title: string) {
  writeJSON(INDEX_KEY, listSessions().map((s) => (s.id === id ? { ...s, title: title.slice(0, 60) } : s)));
  notify();
}

export function deleteSession(id: string) {
  removeKey(msgKey(id));
  writeJSON(INDEX_KEY, listSessions().filter((s) => s.id !== id));
  notify();
}

export function clearAllSessions() {
  listSessions().forEach((s) => removeKey(msgKey(s.id)));
  writeJSON(INDEX_KEY, []);
  notify();
}
