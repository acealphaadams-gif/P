import { useEffect, useState } from "react";
import { readJSON, writeJSON, removeKey } from "./storage";

export const ROLES = ["Learner", "Teacher"] as const;
export const LEVELS = ["Primary (P1–P7)", "O-Level (S1–S4)", "A-Level (S5–S6)", "Tertiary / Other"] as const;
export const PREFERENCES = [
  "Step-by-step working",
  "Short answers",
  "Real-life Ugandan examples",
  "Practice questions",
  "Simple English",
  "Exam (UNEB) style tips",
] as const;
export const SUBJECTS = ["Any subject", "Mathematics", "English", "Physics", "Chemistry", "Biology", "Geography", "History", "Agriculture", "ICT", "Entrepreneurship", "Science (Primary)", "SST (Primary)"] as const;

export type Profile = {
  name: string;
  role: (typeof ROLES)[number];
  level: (typeof LEVELS)[number];
  preferences: string[];
  createdAt: number;
};

export type Settings = {
  theme: "navy" | "light";
  socratic: boolean;
  subject: string;
  readAloud: boolean;
  enterToSend: boolean;
  mode: "tutor" | "coding" | "translate";
  targetLanguage: string;
  preferOffline: boolean;
};

const PROFILE_KEY = "alpha.profile.v1";
const SETTINGS_KEY = "alpha.settings.v1";

export const defaultSettings: Settings = {
  theme: "navy",
  socratic: false,
  subject: "Any subject",
  readAloud: false,
  enterToSend: true,
  mode: "tutor",
  targetLanguage: "English",
  preferOffline: false,
};

function isProfile(v: unknown): v is Profile {
  const p = v as Profile;
  return !!p && typeof p.name === "string" && p.name.length > 0 &&
    (ROLES as readonly string[]).includes(p.role) && (LEVELS as readonly string[]).includes(p.level) &&
    Array.isArray(p.preferences);
}

export const loadProfile = () => readJSON<Profile | null>(PROFILE_KEY, null, (v): v is Profile | null => isProfile(v));
export const saveProfile = (p: Profile) => writeJSON(PROFILE_KEY, p);
export const clearProfile = () => removeKey(PROFILE_KEY);
export const loadSettings = (): Settings => ({ ...defaultSettings, ...readJSON<Partial<Settings>>(SETTINGS_KEY, {}) });
export const saveSettings = (s: Settings) => writeJSON(SETTINGS_KEY, s);

export function applyTheme(theme: Settings["theme"]) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("light", theme === "light");
}

/** Client-only profile+settings state. `ready` is false until storage was read (avoids hydration mismatch). */
export function useAlphaState() {
  const [ready, setReady] = useState(false);
  const [profile, setProfileState] = useState<Profile | null>(null);
  const [settings, setSettingsState] = useState<Settings>(defaultSettings);

  useEffect(() => {
    const s = loadSettings();
    setProfileState(loadProfile());
    setSettingsState(s);
    applyTheme(s.theme);
    setReady(true);
  }, []);

  const setProfile = (p: Profile) => { saveProfile(p); setProfileState(p); };
  const setSettings = (s: Settings) => { saveSettings(s); applyTheme(s.theme); setSettingsState(s); };
  return { ready, profile, settings, setProfile, setSettings };
}
