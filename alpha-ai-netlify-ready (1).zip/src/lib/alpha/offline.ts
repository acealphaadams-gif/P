// Optional on-device AI (WebLLM + WebGPU). Loaded only on user request; nothing runs during SSR.
import type { ChatTransport, UIMessage, UIMessageChunk } from "ai";
import { useEffect, useState } from "react";
import { buildInstructions, type TutorContext } from "@/lib/ai/instructions";

export const OFFLINE_MODEL = "Qwen2.5-1.5B-Instruct-q4f16_1-MLC";
export const OFFLINE_SIZE = "about 1 GB";

type Engine = import("@mlc-ai/web-llm").MLCEngineInterface;
export type OfflineState =
  | { status: "unsupported"; reason: string }
  | { status: "idle"; cached: boolean }
  | { status: "loading"; progress: number; text: string }
  | { status: "ready" }
  | { status: "error"; message: string };

let engine: Engine | null = null;
let state: OfflineState = { status: "idle", cached: false };
const subs = new Set<(s: OfflineState) => void>();
const set = (s: OfflineState) => { state = s; subs.forEach((f) => f(s)); };

async function detect() {
  if (typeof navigator === "undefined") return;
  const gpu = (navigator as Navigator & { gpu?: { requestAdapter: () => Promise<unknown> } }).gpu;
  if (!gpu) return set({ status: "unsupported", reason: "This browser/device has no WebGPU. Try recent Chrome or Edge on a newer computer or Android phone." });
  try {
    if (!(await gpu.requestAdapter())) return set({ status: "unsupported", reason: "No compatible graphics chip was found on this device." });
    const { hasModelInCache } = await import("@mlc-ai/web-llm");
    set({ status: "idle", cached: await hasModelInCache(OFFLINE_MODEL) });
  } catch {
    set({ status: "idle", cached: false });
  }
}
let detected = false;

export function useOffline() {
  const [s, setS] = useState<OfflineState>(state);
  useEffect(() => {
    subs.add(setS);
    if (!detected) { detected = true; void detect(); }
    setS(state);
    return () => { subs.delete(setS); };
  }, []);
  return s;
}

export const offlineReady = () => !!engine && state.status === "ready";

export async function loadOffline() {
  if (engine || state.status === "loading" || state.status === "unsupported") return;
  set({ status: "loading", progress: 0, text: "Starting…" });
  try {
    const { CreateMLCEngine } = await import("@mlc-ai/web-llm");
    engine = await CreateMLCEngine(OFFLINE_MODEL, {
      initProgressCallback: (r) => set({ status: "loading", progress: r.progress, text: r.text }),
    });
    set({ status: "ready" });
  } catch (e) {
    engine = null;
    set({ status: "error", message: (e as Error)?.message?.slice(0, 200) || "Could not load the offline model." });
  }
}

export async function deleteOffline() {
  try {
    await engine?.unload();
    engine = null;
    const { deleteModelAllInfoInCache } = await import("@mlc-ai/web-llm");
    await deleteModelAllInfoInCache(OFFLINE_MODEL);
  } finally {
    set({ status: "idle", cached: false });
  }
}

/** Chat transport that answers with the on-device model, streaming like the online tutor. */
export class OfflineTransport implements ChatTransport<UIMessage> {
  constructor(private ctx: () => TutorContext) {}
  async sendMessages({ messages, abortSignal }: Parameters<ChatTransport<UIMessage>["sendMessages"]>[0]) {
    const eng = engine;
    if (!eng) throw new Error(JSON.stringify({ error: "Offline AI isn't loaded. Open Preferences → Offline AI to load it." }));
    const history = messages.slice(-12).map((m) => ({
      role: m.role === "user" ? ("user" as const) : ("assistant" as const),
      content: m.parts.map((p) => (p.type === "text" ? p.text : p.type === "file" ? "[image omitted: offline AI can't see images]" : "")).join(""),
    })).filter((m) => m.content);
    const system = buildInstructions(this.ctx()) + "\nYou are running offline on the user's device with a small model: keep answers concise.";
    return new ReadableStream<UIMessageChunk>({
      async start(c) {
        const id = "t" + Date.now();
        const onAbort = () => eng.interruptGenerate();
        abortSignal?.addEventListener("abort", onAbort);
        try {
          c.enqueue({ type: "start" });
          c.enqueue({ type: "text-start", id });
          const stream = await eng.chat.completions.create({ messages: [{ role: "system", content: system }, ...history], stream: true });
          for await (const ch of stream) {
            const d = ch.choices[0]?.delta?.content;
            if (d) c.enqueue({ type: "text-delta", id, delta: d });
          }
          c.enqueue({ type: "text-end", id });
          c.enqueue({ type: "finish" });
        } catch (e) {
          c.enqueue({ type: "error", errorText: (e as Error)?.message || "Offline AI failed." });
        } finally {
          abortSignal?.removeEventListener("abort", onAbort);
          c.close();
        }
      },
    });
  }
  async reconnectToStream() { return null; }
}
