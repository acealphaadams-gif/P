import { readJSON, writeJSON } from "./storage";

export type Notice = {
  id: string;
  title: string;
  body: string;
  date?: string;
  source?: string;
  link?: { label: string; href: string };
};

/** Static fallback + official deep-links when live fetch is unavailable */
export const OFFICIAL_LINKS: Notice[] = [
  {
    id: "uneb-home",
    title: "UNEB official website",
    body: "Exam registration, timetables, results and circulars from the Uganda National Examinations Board.",
    source: "UNEB",
    link: { label: "Open uneb.ac.ug", href: "https://uneb.ac.ug" },
  },
  {
    id: "ncdc-home",
    title: "NCDC curriculum",
    body: "Competence-based curriculum materials and syllabi from the National Curriculum Development Centre.",
    source: "NCDC",
    link: { label: "Open ncdc.go.ug", href: "https://ncdc.go.ug" },
  },
  {
    id: "moes-home",
    title: "Ministry of Education",
    body: "Policy updates and education sector news from the Ministry of Education and Sports.",
    source: "MoES",
    link: { label: "Open education.go.ug", href: "https://www.education.go.ug" },
  },
];

const READ_KEY = "alpha.notices.read.v1";
const CACHE_KEY = "alpha.notices.live.v1";

export const loadRead = () => readJSON<string[]>(READ_KEY, [], (v): v is string[] => Array.isArray(v));
export const saveRead = (ids: string[]) => writeJSON(READ_KEY, ids);

export function loadCachedNotices(): Notice[] {
  const cached = readJSON<{ at: number; items: Notice[] } | null>(CACHE_KEY, null, (v): v is { at: number; items: Notice[] } =>
    !!v && typeof v === "object" && Array.isArray((v as { items?: unknown }).items),
  );
  if (cached && Date.now() - cached.at < 6 * 60 * 60 * 1000 && cached.items.length) return cached.items;
  return [];
}

export function saveCachedNotices(items: Notice[]) {
  writeJSON(CACHE_KEY, { at: Date.now(), items });
}

/** Client helper: fetch live UNEB/NCDC notices from our server route */
export async function fetchOfficialNotices(): Promise<Notice[]> {
  try {
    const r = await fetch("/api/news", { headers: { Accept: "application/json" } });
    if (!r.ok) throw new Error(String(r.status));
    const data = (await r.json()) as { items?: Notice[] };
    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length) {
      saveCachedNotices(items);
      return items;
    }
  } catch {
    /* fall through */
  }
  const cached = loadCachedNotices();
  if (cached.length) return cached;
  return OFFICIAL_LINKS;
}
