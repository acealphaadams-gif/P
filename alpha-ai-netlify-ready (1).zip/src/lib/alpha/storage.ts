// Safe persistent storage: falls back to memory when localStorage is blocked,
// full or corrupted, and reports the failure so the UI can tell the user.
const memory = new Map<string, string>();
let lastError: string | null = null;
const listeners = new Set<(err: string | null) => void>();

function setError(err: string | null) {
  lastError = err;
  listeners.forEach((l) => l(err));
}

export function onStorageError(fn: (err: string | null) => void) {
  listeners.add(fn);
  fn(lastError);
  return () => listeners.delete(fn);
}

function ls(): Storage | null {
  try {
    if (typeof window === "undefined") return null;
    const s = window.localStorage;
    const k = "__alpha_probe__";
    s.setItem(k, "1");
    s.removeItem(k);
    return s;
  } catch {
    return null;
  }
}

export function readJSON<T>(key: string, fallback: T, validate?: (v: unknown) => v is T): T {
  try {
    const raw = ls()?.getItem(key) ?? memory.get(key) ?? null;
    if (raw == null) return fallback;
    const parsed = JSON.parse(raw);
    if (validate && !validate(parsed)) return fallback;
    return parsed as T;
  } catch {
    setError("Some saved data was unreadable and has been reset.");
    return fallback;
  }
}

export function writeJSON(key: string, value: unknown): boolean {
  const raw = JSON.stringify(value);
  memory.set(key, raw);
  const s = ls();
  if (!s) {
    setError("Browser storage is unavailable (private mode?). Your chats will be lost when you close this tab.");
    return false;
  }
  try {
    s.setItem(key, raw);
    if (lastError) setError(null);
    return true;
  } catch {
    setError("Storage is full. Delete some old chats so new messages can be saved.");
    return false;
  }
}

export function removeKey(key: string) {
  memory.delete(key);
  try { ls()?.removeItem(key); } catch { /* ignore */ }
}
