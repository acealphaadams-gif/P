import { readJSON, writeJSON, removeKey } from "./storage";

export type AuthUser = {
  email: string;
  name: string;
  createdAt: number;
};

const USER_KEY = "alpha.auth.user.v1";
const CREDS_KEY = "alpha.auth.creds.v1"; // email -> { salt, hash, name }

type CredMap = Record<string, { salt: string; hash: string; name: string }>;

function toHex(buf: ArrayBuffer) {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hashPassword(password: string, salt: string) {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const dig = await crypto.subtle.digest("SHA-256", data);
  return toHex(dig);
}

function randomSalt() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return toHex(a.buffer);
}

export function getSessionUser(): AuthUser | null {
  return readJSON<AuthUser | null>(USER_KEY, null, (v): v is AuthUser =>
    !!v && typeof v === "object" && typeof (v as AuthUser).email === "string",
  );
}

export function setSessionUser(user: AuthUser | null) {
  if (!user) removeKey(USER_KEY);
  else writeJSON(USER_KEY, user);
}

export async function signUp(email: string, password: string, name: string): Promise<AuthUser> {
  const e = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new Error("Enter a valid email address.");
  if (password.length < 6) throw new Error("Password must be at least 6 characters.");
  if (!name.trim()) throw new Error("Enter your name.");
  const map = readJSON<CredMap>(CREDS_KEY, {}, (v): v is CredMap => !!v && typeof v === "object");
  if (map[e]) throw new Error("An account with this email already exists. Sign in instead.");
  const salt = randomSalt();
  const hash = await hashPassword(password, salt);
  map[e] = { salt, hash, name: name.trim() };
  writeJSON(CREDS_KEY, map);
  const user: AuthUser = { email: e, name: name.trim(), createdAt: Date.now() };
  setSessionUser(user);
  return user;
}

export async function signIn(email: string, password: string): Promise<AuthUser> {
  const e = email.trim().toLowerCase();
  const map = readJSON<CredMap>(CREDS_KEY, {}, (v): v is CredMap => !!v && typeof v === "object");
  const row = map[e];
  if (!row) throw new Error("No account found for that email. Create one below.");
  const hash = await hashPassword(password, row.salt);
  if (hash !== row.hash) throw new Error("Incorrect password.");
  const user: AuthUser = { email: e, name: row.name, createdAt: Date.now() };
  setSessionUser(user);
  return user;
}

export function signOut() {
  setSessionUser(null);
}
