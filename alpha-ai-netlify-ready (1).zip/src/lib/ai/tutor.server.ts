import { createOpenAI } from "@ai-sdk/openai";
import { convertToModelMessages, streamText, type UIMessage } from "ai";

import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "./run-id.server";
import { buildInstructions, type TutorContext } from "./instructions";

const DEFAULT_GATEWAY = "https://ai.gateway.lovable.dev/v1";
const DEFAULT_MODEL = "openai/gpt-6-astra";
const MAX_MESSAGES = Number(process.env["MAX_MESSAGES"] || 200);
const MAX_BODY_BYTES = Number(process.env["MAX_UPLOAD_MB"] || 100) * 1.4 * 1024 * 1024;

/**
 * Backend AI config. Defaults talk to the Lovable AI Gateway; self-hosters can
 * point Alpha at any OpenAI-compatible server with AI_BASE_URL / AI_API_KEY /
 * AI_MODEL. Read inside the handler only — never imported by browser code.
 */
export function aiConfig() {
  const apiKey = process.env["LOVABLE_API_KEY"] || process.env["AI_API_KEY"] || "";
  const baseURL = process.env["AI_BASE_URL"] || DEFAULT_GATEWAY;
  const model = process.env["AI_MODEL"] || DEFAULT_MODEL;
  return { apiKey, baseURL, model, isLovableGateway: baseURL === DEFAULT_GATEWAY };
}

function json(status: number, error: string) {
  return new Response(JSON.stringify({ error }), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function safeError(err: unknown) {
  const e = err as { statusCode?: number; status?: number; message?: string };
  const status = e?.statusCode ?? e?.status;
  if (status === 402) return "Alpha AI has run out of AI credits for now. The app owner needs to add credits.";
  if (status === 429) return "Alpha AI is busy right now (rate limited). Please wait a moment and retry.";
  if (status === 403) return "This request was declined by the AI service.";
  if (status === 401) return "The tutor backend is not configured correctly (invalid server key).";
  if (status === 400) return "The request could not be processed. Try a shorter message or remove the attachment.";
  return "The tutor could not finish this reply. Please retry.";
}

export async function handleChat(request: Request) {
  const { apiKey, baseURL, model, isLovableGateway } = aiConfig();
  if (!apiKey)
    return json(503, "Tutor backend is not configured: the server AI key is missing (set LOVABLE_API_KEY or AI_API_KEY).");

  const len = Number(request.headers.get("content-length") ?? 0);
  if (len > MAX_BODY_BYTES) return json(413, "Message too large. Attachments must be under the server upload limit (MAX_UPLOAD_MB, default 100 MB).");

  let body: { messages?: UIMessage[]; context?: TutorContext };
  try {
    body = await request.json();
  } catch {
    return json(400, "Invalid request.");
  }
  if (!Array.isArray(body.messages) || body.messages.length === 0) return json(400, "No messages sent.");

  // Only allow user/assistant roles and safe part types from the client.
  const messages = body.messages.slice(-MAX_MESSAGES).filter(
    (m) => m && (m.role === "user" || m.role === "assistant") && Array.isArray(m.parts),
  ).map((m) => ({
    ...m,
    parts: m.parts.filter((p) => {
      if (p.type === "text") return true;
      if (p.type === "file") {
        const fp = p as { mediaType?: string; url?: string };
        return /^(image\/(png|jpeg|webp|gif)|application\/pdf)$/.test(fp.mediaType ?? "") && (fp.url ?? "").startsWith("data:");
      }
      return false;
    }),
  })).filter((m) => m.parts.length > 0);

  if (!messages.length) return json(400, "No valid messages sent.");

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL,
    apiKey,
    ...(isLovableGateway
      ? { headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" }, fetch: runIdFetch.fetch }
      : {}),
  });

  const result = streamText({
    model: isLovableGateway ? provider.responses(model) : provider.chat(model),
    instructions: buildInstructions(body.context ?? {}),
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
    maxRetries: 0,
    ...(isLovableGateway
      ? {
          providerOptions: {
            openai: {
              forceReasoning: true,
              reasoningEffort: body.context?.mode === "coding" ? "medium" : "low",
              reasoningSummary: "auto",
              store: false,
              include: ["reasoning.encrypted_content"],
            },
          },
        }
      : {}),
  });

  const response = result.toUIMessageStreamResponse({ sendReasoning: false, onError: safeError });
  return isLovableGateway ? withLovableAiGatewayRunIdHeader(response, runIdFetch) : response;
}
