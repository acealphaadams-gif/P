# Alpha AI — Easy deploy guide (no coding needed)

You need three free accounts:
1. **GitHub** — https://github.com/signup  
2. **Netlify** — https://app.netlify.com  
3. An AI key (pick one):
   - **xAI / Grok** — https://console.x.ai → create API key  
   - **or** OpenAI — https://platform.openai.com  
   - **or** keep using Lovable’s key if you have `LOVABLE_API_KEY`

---

## Step A — Put the project on GitHub

1. On your computer, unzip this project so you see folders like `src`, `public`, `package.json`.
2. Open https://github.com → **New repository**  
   - Name: `alpha-ai`  
   - Public is fine  
   - Do **not** add a README (project already has one)
3. Upload files:
   - Easiest: on the new empty repo page, click **uploading an existing file** and drag **all** project files in, then **Commit**.
   - Or use GitHub Desktop if you prefer.

---

## Step B — Connect Netlify

1. Go to https://app.netlify.com and sign up / log in.
2. **Add new site** → **Import an existing project**.
3. Choose **GitHub** and allow access.
4. Select the `alpha-ai` repository.
5. Build settings (should autofill from `netlify.toml`):
   - Build command: `npm run build`
   - Publish directory: `dist/client`
6. Click **Deploy site**. Wait until it finishes (a few minutes).

You will get a link like `https://random-name.netlify.app`.

---

## Step C — Add the AI key (so chat works)

1. In Netlify open your site → **Site configuration** → **Environment variables**.
2. **Add a variable**:

### Option 1 — Grok (xAI) recommended
| Name | Value |
|------|--------|
| `AI_API_KEY` | your key from console.x.ai |
| `AI_BASE_URL` | `https://api.x.ai/v1` |
| `AI_MODEL` | `grok-2-latest` |

### Option 2 — OpenAI
| Name | Value |
|------|--------|
| `AI_API_KEY` | your OpenAI key |
| `AI_BASE_URL` | `https://api.openai.com/v1` |
| `AI_MODEL` | `gpt-4o-mini` |

### Option 3 — Lovable gateway
| Name | Value |
|------|--------|
| `LOVABLE_API_KEY` | your Lovable key |

3. Save variables.
4. **Deploys** → **Trigger deploy** → **Deploy site** (required after adding keys).

---

## Step D — Check it works

1. Open your Netlify URL.
2. Create account or **Continue as guest**.
3. Finish personalization.
4. Send: `Hello Alpha`.
5. Preferences → Tutor service should say connected.

---

## Sign-in page

Open: `https://YOUR-SITE.netlify.app/sign-in`

- Create account / Sign in (saved on that device’s browser)
- Or continue as guest

---

## UNEB news

The bell icon loads notices from **uneb.ac.ug** (and links to NCDC / MoES).  
If the live fetch fails, official links still appear.

---

## Common problems

| Problem | Fix |
|---------|-----|
| Chat says backend not configured | Env vars missing → add key → **redeploy** |
| Build failed on Netlify | Open deploy log; usually missing `package-lock` is fine — ensure Node 22 |
| News empty | Site may block servers; fallback official links still show |
| Want a custom domain | Netlify → Domain management → Add domain |

You do **not** need to run Python or Terminal on your PC for this path.
