# Alpha AI — Your Friendly Tutor

AI tutoring for Ugandan learners and teachers (NCDC competence-based curriculum, UNEB exams), plus a coding mode and a world-language translator. Runs as a web app on phone or desktop.

> **Source note:** the original `alpha-netlify.zip` was never attached to this project. This codebase is a rebuild from the written brief, not a migration of those files.

## What's in it

- **Onboarding** — floating logo, then preferred name, role (Learner / Teacher), study level, learning preferences. Returning users go straight to their latest chat.
- **Tutor mode** — step-by-step explanations with LaTeX maths (KaTeX), optional Socratic hint-by-hint mode, different voice for teachers vs learners.
- **Coding mode** — writes complete code in any language, with copy / download / in-browser run for HTML and JavaScript snippets.
- **Translate mode** — any world language in or out, including Luganda, Runyankole, Acholi, Lusoga, Ateso, Lugbara, Swahili, Kinyarwanda. Low-resource languages are flagged as possibly imperfect rather than presented as exact.
- **Offline AI (optional download)** — Preferences → Offline AI downloads a small on-device model (about 1 GB). Chat then answers with no internet. Needs WebGPU (recent Chrome / Edge on a newer computer or Android phone); the app itself still needs internet the first time it opens.
- **Chat sessions** — new chat, rename, delete, search-free sidebar list, persisted locally.
- **Attachments** — PNG / JPG / WEBP / GIF (magic-byte checked) and TXT / MD / CSV, max 4 MB. PDFs are not supported; upload a photo or screenshot of the page instead.
- **Voice** — dictation and read-aloud where the browser supports it, with a clear "not supported here" message where it doesn't.
- **Notifications, preferences, theme** — all live controls; anything unavailable is shown disabled with a reason.
- **Honest states** — backend health check at `/api/health`, distinct errors for missing key / no credits / rate limits, and a warning when browser storage is full or blocked.

## Run locally

```sh
npm install          # or: bun install
cp .env.example .env # then put a key in it
npm run dev          # http://localhost:8080
```

## Backend configuration

The chat is answered by your server, not the browser. The route `/api/chat` reads these variables at runtime:

| Variable | Purpose |
| --- | --- |
| `LOVABLE_API_KEY` | Default. Uses the Lovable AI Gateway (`https://ai.gateway.lovable.dev/v1`). |
| `AI_API_KEY` | Alternative key, used if `LOVABLE_API_KEY` is unset. |
| `AI_BASE_URL` | Any OpenAI-compatible server, e.g. `https://api.openai.com/v1` or a local Ollama endpoint. |
| `AI_MODEL` | Model name for that server, e.g. `gpt-4o-mini`. |

With no key at all the app still opens and explains that the tutor backend is not configured — it never pretends to answer.

The key is read only inside server code and is never shipped to the browser.

## Build and host it yourself

```sh
npm run build
```

The default build targets Cloudflare Workers (that is what Lovable deploys). To run it on your own machine or VPS with Node:

```sh
NITRO_PRESET=node-server npm run build
node .output/server/index.mjs     # serve .output/public behind it, or let it serve everything
```

The host must run server code, because `/api/chat` and `/api/health` are server routes.

### Netlify (ready to go)

`netlify.toml` and `netlify/functions/server.mjs` are included. The normal `npm run build` output is served by Netlify's CDN (`dist/client`) and the server (pages, `/api/chat`, `/api/health`) runs as one Netlify Function.

1. Push this folder to GitHub/GitLab and "Import an existing project" in Netlify (or run `npx netlify deploy --build --prod` with the Netlify CLI).
2. In **Site settings → Environment variables** add `LOVABLE_API_KEY` — or, for any OpenAI-compatible provider, `AI_API_KEY`, `AI_BASE_URL` and `AI_MODEL`.
3. Redeploy. Preferences → "Tutor service" should say "Connected and configured."

Streaming answers work on Netlify Functions; very long replies may hit Netlify's function time limit on the free plan.

**Netlify drag-and-drop (static only) cannot run the tutor** — use the Git/CLI deploy above.

### Offline AI

Preferences → Offline AI downloads a small model (~1 GB, WebGPU browsers only) into the browser. Once loaded, Alpha switches to it automatically when the device loses internet or the server is unreachable, and you can force it with "Prefer offline AI". It is much weaker than the online tutor and cannot read images; the app itself must already be open (no installed offline shell).

## Things to know before you deploy

- **No accounts.** Profile, preferences and chat history live in that browser's `localStorage` only — nothing syncs between devices, and clearing browser data clears the chats.
- **Images are not kept** in saved history (to stay inside storage limits).
- **The offline model is much weaker** than the online tutor: it is a 1.5B parameter model, can't see attached images, and only runs on WebGPU devices. It is a fallback, not a replacement.
- **No live UNEB / NCDC news.** The tutor has no feed of exam dates, results or announcements and is instructed to send users to uneb.ac.ug, ncdc.go.ug, education.go.ug instead of guessing.
- **No payments** of any kind are implemented.
- **Translation quality varies** — strong for well-resourced languages, honest-but-imperfect for many local ones.

## Checks

```sh
npm run test     # vitest
npx tsgo --noEmit   # or npx tsc --noEmit
npm run lint
```

## Layout

```
src/routes/          pages + /api/chat and /api/health server routes
src/components/alpha/  the app's own UI (logo, onboarding, chat, sidebar, settings…)
src/components/ui/     shadcn-style primitives
src/lib/ai/         prompt builder (shared) + server-side model call
src/lib/alpha/      storage, profile, sessions, voice, offline model, notices
src/test/           tests
```

## Meetings (online collaboration)

Sidebar → **Meetings**: schedule student discussions, teacher meetings, lessons or parent meetings, copy the link, and join video calls inside the app. Calls run on the free public Jitsi Meet service (meet.jit.si); anyone with the link can join. Meeting lists are saved in the browser only.

## Upload size

The app accepts files up to 100 MB. The server limit is set by `MAX_UPLOAD_MB` (default 100) and chat history length by `MAX_MESSAGES` (default 200). Your host must also allow big requests:
- **Netlify Functions: hard 6 MB request limit** — big uploads will fail there. Use a Node server/VPS instead.
- **Node server / VPS:** no limit except your reverse proxy (nginx: `client_max_body_size 150m;`).
- The AI model itself also has a size limit per file (roughly 20–50 MB for PDFs, depending on the provider).

## Step-by-step backend deploy (VPS / Node, recommended for big uploads)

1. Get a Linux server (Ubuntu 22+), install Node 22: `curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt install -y nodejs nginx`.
2. Upload and unzip this folder, then: `npm install`.
3. Create `.env` from `.env.example` with `LOVABLE_API_KEY=...` (or `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` for any OpenAI-compatible provider).
4. Build: `NITRO_PRESET=node-server npm run build`.
5. Run it permanently: `npm i -g pm2 && pm2 start .output/server/index.mjs --name alpha && pm2 save && pm2 startup`. It listens on port 3000 (`PORT=` to change).
6. nginx: proxy your domain to `http://127.0.0.1:3000`, set `client_max_body_size 150m;` and `proxy_buffering off;` (needed for streamed answers).
7. HTTPS: `sudo apt install certbot python3-certbot-nginx && sudo certbot --nginx -d yourdomain.com` (microphone, camera and meetings need HTTPS).
8. Open the site → Preferences → "Tutor service" should say connected.
